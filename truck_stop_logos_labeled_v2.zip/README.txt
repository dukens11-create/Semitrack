Truck Stop Logos Labeled v2

Each PNG is:
- separate
- higher resolution
- clearer
- with the brand name at the top

Files:
mobil.png
exxon.png
chevron.png
shell.png
bp.png
circle_k.png
petro_canada.png
esso.png
t_default.png
